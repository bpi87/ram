from otree.api import Currency as c, currency_range
from . import pages
from ._builtin import Bot
from .models import Constants
from random import randint


class PlayerBot(Bot):
    pass
